import speech_recognition as sr
import random
import time
from lisansd import lisans

print("=== İngilizce Kelime Oyunu sürümü 1.2 ===")

print("uyarı: en güncel sürümü kullanmanız önerilir.")
    
seviyeye_gore_kelimeler = {
    "kolay": ["cat", "dog", "apple", "milk", "sun"],
    "orta": ["banana", "school", "friend", "window"],
    "zor": ["technology", "university", "information"]
}

turkce_karsiliklar = {
    "cat": "kedi", "dog": "köpek", "apple": "elma", "milk": "süt", "sun": "güneş",
    "banana": "muz", "school": "okul", "friend": "arkadaş", "window": "pencere",
    "technology": "teknoloji", "university": "üniversite", "information": "bilgi", 
}

def start_game():
    puan = 0
    
    recognizer = sr.Recognizer()

    while True:

        while True:
            seviye = input("\nLütfen bir seviye seçin (kolay, orta, zor) : ").lower()
            
            if seviye in seviyeye_gore_kelimeler:
                break
            print("geçersiz kelime tekrar deneyin.")
        
        l = input("oyundak çıkmak istiyorsanız'a' basın devam etmek için başka bir tuşa basın: ").lower()
        if l == 'a':
            break
        secilen_kelime = random.choice(seviyeye_gore_kelimeler[seviye])
        dogru_cevap = turkce_karsiliklar[secilen_kelime]
        
        print(f"\n '{secilen_kelime}' türkçe karşılığı nedir")
        
        with sr.Microphone() as source:
            print("Konuşmaya başlayın")
            recognizer.adjust_for_ambient_noise(source)
            
            try:
                audio = recognizer.listen(source, timeout=5)
                text = recognizer.recognize_google(audio, language="tr-TR").lower()
               
                if text == dogru_cevap:
                    print("Doğru bildiniz ")
                    puan += 10
                else:
                    print(f"Maalesef yanlış")

            except sr.UnknownValueError:
                print(" Ses anlaşılamadı! ")
            except sr.RequestError:
                print("Servise ulaşılamıyor, internet bağlantınızı kontrol edin.")
                break
            except Exception as e:
                print(f"Bir hata oluştu {e}")
                break

    print("\n" + "═"*30)
    print(f" Final Puanınız: {puan}")
    print("═"*30)

if __name__ == "__main__":
    start_game()